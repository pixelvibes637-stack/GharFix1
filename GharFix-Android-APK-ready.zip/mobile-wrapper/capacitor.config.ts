import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.gharfix.app',
  appName: 'GharFix',
  webDir: '../artifacts/gharfix/dist/public',
  bundledWebRuntime: false,
  server: {
    androidScheme: 'https'
  }
};

export default config;
